import pandas as pd
df = pd.read_excel('data/raw/input.xlsx')
df.to_parquet('data/processed/raw.parquet')
print('Ingested', len(df), 'rows')
