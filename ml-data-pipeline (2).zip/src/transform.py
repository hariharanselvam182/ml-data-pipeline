import pandas as pd, math
df = pd.read_parquet('data/processed/cleaned.parquet')
df['log_total_spent_30d'] = df['total_spent_30d'].apply(lambda x: math.log(x+1))
df['log_avg_order_value_30d'] = df['avg_order_value_30d'].apply(lambda x: math.log(x+1))
df.to_parquet('data/processed/transformed.parquet')
