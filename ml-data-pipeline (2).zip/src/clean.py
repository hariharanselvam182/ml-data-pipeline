import pandas as pd
df = pd.read_parquet('data/processed/raw.parquet')
df.columns = df.columns.str.lower().str.replace(' ', '_')
df = df.drop_duplicates()
df['snapshot_date'] = pd.to_datetime(df['snapshot_date'], errors='coerce')
df = df.dropna(subset=['user_id','snapshot_date'])
for c in df.select_dtypes('number'):
    df = df[df[c] >= 0]
df.to_parquet('data/processed/cleaned.parquet')
