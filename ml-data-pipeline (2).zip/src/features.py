import pandas as pd
df = pd.read_parquet('data/processed/transformed.parquet')
df['session_intensity'] = df['sessions_7d']/(df['sessions_30d']+1)
df['purchase_intensity'] = df['purchases_7d']/(df['purchases_30d']+1)
df['spend_velocity'] = df['total_spent_30d']/(df['account_age_days']+1)
cols = ['sessions_7d','sessions_30d','pages_viewed_7d','days_since_last_session','purchases_7d','purchases_30d','log_total_spent_30d','log_avg_order_value_30d','session_intensity','purchase_intensity','spend_velocity','is_premium','has_saved_card','support_tickets_30d','will_purchase_7d']
df[cols].to_parquet('data/processed/features.parquet')
