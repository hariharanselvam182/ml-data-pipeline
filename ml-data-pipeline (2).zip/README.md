# ML Data Pipeline
Run src scripts in order: ingest -> clean -> transform -> features -> train
